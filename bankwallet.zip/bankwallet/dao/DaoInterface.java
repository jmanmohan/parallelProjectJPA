package com.cg.bankwallet.dao;

import java.util.List;

import com.cg.bankwallet.bean.Transaction;
import com.cg.bankwallet.bean.Wallet;
import com.cg.bankwallet.exception.WalletNotFound;

public interface DaoInterface {
	
	public Wallet createAccount(Wallet wallet) 
			throws WalletNotFound;
    public Wallet showBalance(int accNumOfUser,int pin) 
    		throws WalletNotFound;
    public Wallet deposit(double amount, int  accNum1) 
    		throws WalletNotFound;
    public Wallet withdraw(double amount,int accNum2, int pin1) 
    		throws WalletNotFound;
    public Wallet fundTransfer(double transferAmount,int accNum3,int accNumBen) 
    		throws WalletNotFound;
    public List<Transaction> transactions(int accNum4,int pin2)
    		throws WalletNotFound;
	

}
