package com.cg.bankwallet.dao;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.cg.bankwallet.bean.Transaction;
import com.cg.bankwallet.bean.Wallet;
import com.cg.bankwallet.exception.WalletNotFound;
import com.cg.bankwallet.utility.JPAUtil;

public class WalletDAOImpl implements DaoInterface {
	Scanner scanner = new Scanner(System.in);
	private EntityManager entityManager = null;
	Transaction transaction = null;

	@Override
	public Wallet createAccount(Wallet wallet) throws WalletNotFound{
try {
			
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			entityManager.persist(wallet);
			entityManager.getTransaction().commit();
		} catch (PersistenceException e) {
			e.printStackTrace();
			
				
		} finally {
			entityManager.close();
		}
return wallet;
	}
	

	@Override
	public Wallet showBalance(int accNumOfUser, int pin) throws WalletNotFound{
		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			Wallet wallet = entityManager.find(Wallet.class, accNumOfUser);
			double bal = wallet.getBalance();
			System.out.println("Balance in your Account is:"+" "+bal);
			entityManager.getTransaction().commit();
		} catch (PersistenceException e) {
			e.printStackTrace();
			
		
		} finally {
			entityManager.close();
		}
		return null;
		

	}
	

	@Override
	public Wallet deposit(double amount, int accNum1) throws WalletNotFound{
		
		try {
			entityManager = JPAUtil.getEntityManager();
			transaction = new Transaction();
			//entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			Wallet wallet = entityManager.find(Wallet.class, accNum1);
			if(wallet.getAccNumOfUser()==accNum1){
				double balance = wallet.getBalance();
				balance = balance+amount;
				wallet.setBalance(balance);
				//entityManager.merge(wallet);
				//transaction.setWallet(wallet);
				transaction.setTransaction("+"+" "+amount);
				entityManager.merge(wallet);
				entityManager.getTransaction().commit();
				}
			
		 System.out.println("Updated Balance:"+" "+wallet.getBalance());
			//entityManager.getTransaction().commit();
		} catch (PersistenceException e) {
			e.printStackTrace();
			
		
		} finally {
			entityManager.close();
		}
		return null;
	}

	@Override
	public Wallet withdraw(double amount, int accNum2, int pin1) throws WalletNotFound{
		try {
			entityManager = JPAUtil.getEntityManager();
			transaction = new Transaction();
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			Wallet wallet = entityManager.find(Wallet.class, accNum2);
			
			if(wallet.getAccNumOfUser()==accNum2 ){
				
				double balance = wallet.getBalance();
				balance = balance-amount;
				wallet.setBalance(balance);
				entityManager.merge(wallet);
				transaction.setWallet(wallet);
				transaction.setTransaction("-"+" "+amount);
				entityManager.persist(transaction);
				
			}
			
		 System.out.println("Updated Balance:"+" "+wallet.getBalance());
			entityManager.getTransaction().commit();
		} catch (PersistenceException e) {
			e.printStackTrace();
			
		
		} finally {
			entityManager.close();
		}
		return null;
	}
	

	@Override
	public Wallet fundTransfer(double transferAmount, int accNum3,
			int accNumBen) throws WalletNotFound {
		 
			try {
					entityManager = JPAUtil.getEntityManager();
					transaction= new Transaction();
					entityManager.getTransaction().begin();
					Wallet wallet01 = entityManager.find(Wallet.class,
							accNum3);
					Wallet wallet02 = entityManager.find(Wallet.class,
							accNumBen);

					Double userBalance = wallet01.getBalance();
					Double beneficiaryBalance = wallet02.getBalance(); 
					userBalance = userBalance - transferAmount;
					transaction.setWallet(wallet01);
					transaction.setTransaction("-"+" "+transferAmount);
					entityManager.persist(transaction);
					beneficiaryBalance = beneficiaryBalance + transferAmount;
					wallet01.setBalance(userBalance);
					wallet02.setBalance(beneficiaryBalance); 
			entityManager.merge(wallet01);
					transaction.setWallet(wallet02);
					transaction.setTransaction("+"+" "+transferAmount);
					entityManager.persist(transaction);
					entityManager.merge(wallet02);

					entityManager.getTransaction().commit();

					System.out.println("Balance in Your Account: "
							+ wallet01.getBalance());
					System.out.println("Balance in Beneficiary Account: "
							+ wallet02.getBalance()); 
			} catch (PersistenceException e) {
					e.printStackTrace();
					// TODO: Log to file
					throw new WalletNotFound(e.getMessage());
				} finally {
					entityManager.close();
				}
			return null;
				
			} 
 

		 
			
		 

	

	@Override

		public List<Transaction> transactions(int accNum4 , int pin2 ) throws WalletNotFound {
		try{
			System.out.println(accNum4);
			entityManager=JPAUtil.getEntityManager();
		
		Query query = entityManager.createQuery(" from Transaction where account_number=?");
		query.setParameter(1, accNum4);
		List<Transaction> list=query.getResultList();
		Iterator<Transaction> iterator = list.iterator();
	
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}
		
		return list;
		 
	}catch(PersistenceException e) {
			e.printStackTrace();
			//Log to file
			throw new WalletNotFound(e.getMessage());
		}finally{
			entityManager.close();
		}		
	}
}

	


