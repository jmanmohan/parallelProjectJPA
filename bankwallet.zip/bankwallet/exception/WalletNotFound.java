package com.cg.bankwallet.exception;

public class WalletNotFound extends Exception{
	private String status;
	
	public WalletNotFound(){
		status = "Wallet Not Found";
	}

	@Override
	public String toString() {
		return "WalletNotFound [status=" + status + "]";
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public WalletNotFound(String status) {
		super();
		this.status = status;
	}

}
